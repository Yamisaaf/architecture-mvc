<?php

print_r($news);
echo "salut je 'mapelle yamisaaf :D test";